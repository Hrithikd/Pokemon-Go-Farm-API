cd pgoapi/protos
protoc *.proto --python_out=.
cd -
